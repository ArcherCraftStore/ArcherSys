
fMath **********************************************

	http://www.fMath.info/

AUTHOR *********************************************

	@author		: Ionel Alexandru
	@mail		: ionel.alexandru@gmail.com
	@blog		: http://mathmlflash.blogspot.com/
	

