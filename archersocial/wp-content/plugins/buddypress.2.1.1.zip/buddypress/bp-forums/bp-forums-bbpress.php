<?php
/**
 * Placeholder for bbPress plugin bridge
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
