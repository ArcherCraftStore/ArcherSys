{
    "LeftAndMain.CONFIRMUNSAVED": "¿Estás seguro que quieres navegar fuera de esta página?⏎\n⏎\nADVERTENCIA: Tus cambios no han sido guardados.⏎\n⏎\nPresionar OK para continuar o Cancelar para continuar en la página actual",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "ADVERTENCIA: Tus cambios no han sido guardados.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "¿Realmente quieres eliminar el grupo %s?",
    "ModelAdmin.SAVED": "Guardado",
    "ModelAdmin.REALLYDELETE": "Estás seguro que quieres eliminarla?",
    "ModelAdmin.DELETED": "Eliminado",
    "ModelAdmin.VALIDATIONERROR": "Error de validación",
    "LeftAndMain.PAGEWASDELETED": "Esta página fue eliminada. Para editar una página, seleccionarla desde la izquierda"
}