{
    "LeftAndMain.CONFIRMUNSAVED": "Etes-vous sûr de vouloir quitter cette page ?\n\nATTENTION: Vos changements n'ont pas été sauvegardés.\n\nCliquez sur OK pour continuer, ou sur Annuler pour rester sur la page actuelle.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNING: Your changes have not been saved.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Do you really want to delete %s groups?",
    "ModelAdmin.SAVED": "Sauvegardé",
    "ModelAdmin.REALLYDELETE": "Etes-vous sûr de vouloir supprimer ?",
    "ModelAdmin.DELETED": "Supprimé",
    "ModelAdmin.VALIDATIONERROR": "Validation Error",
    "LeftAndMain.PAGEWASDELETED": "Cette page a été supprimée. Pour éditer cette page, veuillez la sélectionner à gauche."
}