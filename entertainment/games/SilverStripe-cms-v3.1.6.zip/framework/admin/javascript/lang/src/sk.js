{
    "LeftAndMain.CONFIRMUNSAVED": "Určite chcete opustiť navigáciu z tejto stránky?\n\nUPOZORNENIE: Vaše zmeny neboli uložené.\n\nStlačte OK pre pokračovať, alebo Cancel, ostanete na teto stránke.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "UPOZORNENIE: Vaše zmeny neboli uložené.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Skutočne chcete zmazať % skupiny?",
    "ModelAdmin.SAVED": "Uložené",
    "ModelAdmin.REALLYDELETE": "Skutočně chcete zmazať?",
    "ModelAdmin.DELETED": "Zmazané",
    "ModelAdmin.VALIDATIONERROR": "Chyba platnosti",
    "LeftAndMain.PAGEWASDELETED": "Táto stránka bola zmazaná. Pre editáciu stránky, vyberte ju vľavo."
}