This README explains the structure on the "index.html" so you can better
understand the javascript code.

In the body of the HTML document there are quite a few divs.

The "wrapper" div holds all the other divs.

The "introscreen" div is what is first shown when the user comes to 
the page. We hide this div once the user presses the ENTER key and the game
begins.

The "attributionsdiv" has 12 divs inside it and inside each one of those divs
are <img> and <p> tags. There are 12 images we use in the game, and when we show the 
"attributionsdiv" we dynamically populate these 12 divs with the appropriate photo
and links to the photo on flickr. This div also has the "NEXTLEVEL", and "NEWGAME"
buttons inside it.

The "gamediv" is the main game area, it holds the search input, the "leveldiv" that shows
the current level, and the "infoprogress" and "progressdiv". The "infoprogess" and "progressdiv"
are dynamically set to be visible or hidden at the appropriate times.

The divs "image1" and "image2" are the hold the big images on the left and right
of the main gameplay area.

Most of the divs in the "index.html" are shown and hid at the appropriate times by using
css.

If anything is unclear, please leave a comment on the tutorials homepage.