$(document).ready(function() {
	var flickrGame = {
		APIKEY: "76656089429ab3a6b97d7c899ece839d",
		imageArray: [],
		tempImages:[],
		theImages: [],
		chosenCards: []
    }
	 function randOrd() {
        return (Math.round(Math.random()) - 0.5);
    }
	function doSearch() {
	    if ($("#searchterm").val() != "") {
	        $(document).off("keypress");
            var searchURL = "http://api.flickr.com/services/rest/?method=flickr.photos.search";
            searchURL += "&api_key=" + flickrGame.APIKEY;
            searchURL += "&tags=" + $("#searchterm").val();
            searchURL += "&per_page=36"
            searchURL += "&license=5,7";
            searchURL += "&format=json";
            searchURL += "&jsoncallback=?";
            $.getJSON(searchURL, setImages);
        }
	}
	
	function setImages(data) {
		$.each(data.photos.photo, function (i, item) {
			var imageURL = 'http://farm' + item.farm + '.static.flickr.com/' + item.server + '/' + item.id + '_' + item.secret + '_' + 'q.jpg';
			flickrGame.imageArray.push({
                    imageUrl: imageURL,
                    photoid: item.id
                });
        });
		
		infoLoaded();
    }
	
	function infoLoaded(data) {
		preloadImages();
	}
	
	
	function preloadImages(){
		flickrGame.tempImages = flickrGame.imageArray.splice(0, 12);
        for (var i = 0; i < flickrGame.tempImages.length; i++) {
            for (var j = 0; j < 2; j++) {
                var tempImage = new Image();
                tempImage.src = "cardFront.png";
                tempImage.imageSource = flickrGame.tempImages[i].imageUrl;
                flickrGame.theImages.push(tempImage);
               
            }
        }
		drawImages();
	}
	
	function drawImages() {
		flickrGame.theImages.sort(randOrd);
        for (var i = 0; i < flickrGame.theImages.length; i++) {
            $(flickrGame.theImages[i]).attr("class", "card").appendTo("#gamediv");
        }
		addListeners();
    }
	
	function addListeners() {
        for (var i = 0; i < flickrGame.theImages.length; i++) {
            $(flickrGame.theImages[i]).on("click", function (e) {
                doFlip(e);
            });
        }
    }
	
	function removeListeners() {
        for (var i = 0; i < flickrGame.theImages.length; i++) {
            $(flickrGame.theImages[i]).off("click");
        }
    }
	
	function doFlip(e) {
        var theCard = e.target;
        $(theCard).attr("src", theCard.imageSource);
        if ($('#image1').css('backgroundImage') == "none") {
            $('#image1').css('backgroundImage', 'url(' + theCard.imageSource + ')');
        } else {
            $('#image2').css('backgroundImage', 'url(' + theCard.imageSource + ')');
        }
        if (flickrGame.chosenCards.indexOf(theCard) == -1) {
            flickrGame.chosenCards.push(theCard);
            $(theCard).off("click");
        }

        if (flickrGame.chosenCards.length == 2) {
            removeListeners();
            checkForMatch();

        }
    }
	
	 function checkForMatch() {
        if (flickrGame.chosenCards.length == 2) {
            if ($("#image1").css('background-image') == $("#image2").css('background-image')) {
				setTimeout(hideCards, 1000);
            } else {
                setTimeout(resetImages, 1000);
            }
        }

    }
	
	 function hideCards() {
        $(flickrGame.chosenCards[0]).animate({
            'opacity': '0'
        });
        $(flickrGame.chosenCards[1]).animate({
            'opacity': '0'
        });
        flickrGame.theImages.splice(flickrGame.theImages.indexOf(flickrGame.chosenCards[0]), 1);
        flickrGame.theImages.splice(flickrGame.theImages.indexOf(flickrGame.chosenCards[1]), 1);
        $("#image1").css('background-image', 'none');
        $("#image2").css('background-image', 'none');
        addListeners();
        flickrGame.chosenCards = new Array();

    }
	
	
    function resetImages() {
        $(flickrGame.chosenCards[0]).attr("src", "cardFront.png");
        $(flickrGame.chosenCards[1]).attr("src", "cardFront.png");
        $("#image1").css('background-image', 'none');
        $("#image2").css('background-image', 'none');
        addListeners();
        flickrGame.chosenCards = new Array();
    }
    function addKeyPress() {
        $(document).on("keypress", function (e) {
            if (e.keyCode == 13) {
              doSearch();
        }
        });
    }
    
	addKeyPress();
});